﻿namespace jQueryAjaxDemo.Models
{
	public class Cliente
	{
		public int Id { get; set; }
		public string Nome { get; set; }
		public string Endereco { get; set; }
	}
}
